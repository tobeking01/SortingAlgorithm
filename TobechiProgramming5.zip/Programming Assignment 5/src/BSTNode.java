/**
 * 
 * @author Tobechi Onwenu
 * Generic Node class
 *
 * @param <E>
 */
public class BSTNode<E> {

	E data;
	BSTNode<E> left;
	BSTNode<E> right;

	public BSTNode(E parent, BSTNode<E> objectLeft, BSTNode<E> objectRight) {
		data = parent;
		left = objectLeft;
		right = objectRight;
	}

	/**
	 * @return the data
	 */
	public E getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(E data) {
		this.data = data;
	}

	/**
	 * @return the left
	 */
	public BSTNode<E> getLeft() {
		return left;
	}

	/**
	 * @param left the left to set
	 */
	public void setLeft(BSTNode<E> left) {
		this.left = left;
	}

	/**
	 * @return the right
	 */
	public BSTNode<E> getRight() {
		return right;
	}

	/**
	 * @param right the right to set
	 */
	public void setRight(BSTNode<E> right) {
		this.right = right;
	}

}
