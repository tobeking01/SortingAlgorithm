import java.text.DecimalFormat;
/**
 * 
 * 
 * @author Tobechi Onwenu
 * Programming Assignment 5
 * Binary Linked list
 *
 */

public class MenuItem implements Comparable<MenuItem> {

	private String name;
	private int qty;
	private double price;

	/**
	 * @param name
	 * @param qty
	 * @param price
	 */
	public MenuItem(String name, int qty, double price) {
		this.name = name;
		this.qty = qty;
		this.price = price;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof MenuItem)) {
			return false;
		}
		MenuItem other = (MenuItem) obj;
		if (name == null) {
			if (other.name != null) {
				return false;
			}
		} else if (!name.equalsIgnoreCase(other.name)) {
			return false;
		}
		return true;
	}

	@Override
	public int compareTo(MenuItem other) {
		return name.compareToIgnoreCase(other.name);
	}


	@Override
	public String toString() {

		DecimalFormat fl = new DecimalFormat("0.00");
		double total = qty * price;
		return name + "\t$" + price + "\t" + qty + "\t$" + fl.format(total);
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the qty
	 */
	public int getQty() {
		return qty;
	}

	/**
	 * @param qty
	 *            the qty to set
	 */
	public void setQty(int qty) {
		this.qty = qty;
	}

	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * @param price
	 *            the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}

}
