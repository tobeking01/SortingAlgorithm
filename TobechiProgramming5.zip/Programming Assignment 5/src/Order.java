import java.text.DecimalFormat;
/**
 * 
 * @author Tobechi Onwenu for a collection of orders
 * BinaryNode Program detail
 *
 */

public class Order {
	private BSTNode<MenuItem> root;
	private String tableNumber;
	private static String name = "JollyRancher Resturant";

	public Order(String number) {
		root = null;
		tableNumber = number;
	}

	public void insert(MenuItem element) {
		if (root == null) {
			root = new BSTNode<MenuItem>(element, null, null);
		} else {
			insert(root, element);
		}
	}

	private void insert(BSTNode<MenuItem> root, MenuItem element) {
		if (element.compareTo(root.getData()) <= 0) {
			if (root.getLeft() == null) {
				root.setLeft(new BSTNode<MenuItem>(element, null, null));
			} else {
				insert(root.getLeft(), element);
			}
		}else		
			if (root.getRight() == null) {
				root.setRight(new BSTNode<MenuItem>(element, null, null));
			} else {
				insert(root.getRight(), element);
			}
		}

	public void preorder() {
		preorder(root);
	}

	private void preorder(BSTNode<MenuItem> root) {
		if (root != null) {
			System.out.println(root.getData());
			preorder(root.getLeft());
			preorder(root.getRight());
		}
	}

	public void inorder() {
		inorder(root);
	}

	private void inorder(BSTNode<MenuItem> root) {
		if (root != null) {
			inorder(root.getLeft());
			System.out.println(root.getData());
			inorder(root.getRight());
		}
	}

	public void postorder() {
		postorder(root);
	}

	private void postorder(BSTNode<MenuItem> root) {
		if (root != null) {
			postorder(root.getLeft());
			postorder(root.getRight());
			System.out.println(root.getData());
		}
	}

	public int size() {
		return size(root);
	}

	private int size(BSTNode<MenuItem> root) {
		if (root != null)
			return size(root.getLeft()) + 1 + size(root.getRight());
		return 0;
	}

	public int depth() {
		return depth(root);
	}

	private int depth(BSTNode<MenuItem> root) {
		if (root == null) {
			return -1;
		} else {
			int leftDepth = depth(root.getLeft());
			int rightDepth = depth(root.getRight());
			if (leftDepth > rightDepth) {
				return (leftDepth + 1);
			} else
				return (rightDepth + 1);
		}
	}

	public int getTotalQty() {
		return getTotalQty(root);
	}

	private int getTotalQty(BSTNode<MenuItem> root) {
		int total = 0;
		if (root != null) {
			total += getTotalQty(root.getLeft());
			total += getTotalQty(root.getRight());
			total += root.getData().getQty();
		}
		return total;
	}

	public MenuItem search(String item) {
		return search(item, root);
	}

	public MenuItem search(String item, BSTNode<MenuItem> root) {
		if (root == null) {
			return null;
		} else if (item.equals(root.getData().getName())) {
			return root.getData();
		} else {
			if (item.compareTo(root.getData().getName()) < 0) {
				return search(item, root.getLeft());
			} else {
				return search(item, root.getRight());
			}
		}
	}

	public double getTotalBeforeTax() {
		return getTotalBeforeTax(root);
	}

	private double getTotalBeforeTax(BSTNode<MenuItem> root) {
		double total = 0;
		if (root != null) {
			total += getTotalBeforeTax(root.getLeft());
			total += getTotalBeforeTax(root.getRight());
			total += root.getData().getPrice() * root.getData().getQty();
		}
		return total;
	}

	public double getTax(double taxPercent) {
		double taxAmount = 0;
		double taxFinal = 0;
		taxAmount = getTotalBeforeTax();
		taxFinal = taxAmount * taxPercent;
		return taxFinal;
	}

	public double getTip(double tipPercent) {
		double totalAmount = 0;
		double tipAmount = 0;
		totalAmount = getTotalBeforeTax();
		tipAmount = totalAmount * tipPercent;
		return tipAmount;
	}

	public String toString() {
		DecimalFormat fl = new DecimalFormat("0.00");
		double total = 0;
		total = +getTotalBeforeTax() + getTax(0.08) + getTip(0.2);
		String temp = "";
		temp += name + "\t" + tableNumber + "\n";
		temp += "----------------------------------------------\n";
		temp += "Item \t Price \t Qty \t  total \n";
		temp += "----------------------------------------------\n";
		temp += toString(root);
		temp += "----------------------------------------------\n";
		temp += "Total: $" + fl.format(getTotalBeforeTax()) + "\n";
		temp += "Tax: $" + fl.format(getTax(0.08)) + "\n";
		temp += "Tip: $" + fl.format(getTip(0.2)) + "\n";
		temp += "----------------------------------------------\n";
		temp += "Grand Total: $" + fl.format(total);
		return temp;
	}

	private String toString(BSTNode<MenuItem> root) {
		String result = "";
		if (root != null) {
			result += toString(root.getLeft());
			result += root.getData().toString() + "\n";
			result += toString(root.getRight());
		}
		return result;
	}

}
