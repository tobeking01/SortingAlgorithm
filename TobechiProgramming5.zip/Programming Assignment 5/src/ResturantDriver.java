import java.text.DecimalFormat;
/**
 * 
 * @author Tobechi Onwewnu
 * Driver class
 *
 */

public class ResturantDriver {

	public static void main(String[] args) {
		DecimalFormat fl = new DecimalFormat("0.00");
		Order order1 = new Order("Table 1");
		Order order2 = new Order("Table 2");
		
		MenuItem item1 = new MenuItem("Injera", 1, 4.50);
		MenuItem item2 = new MenuItem("Rice", 3, 2.50);
		MenuItem item3 = new MenuItem("Sambusa", 4, 8.20);
		MenuItem item4 = new MenuItem("Sushi", 2, 5.50);
		MenuItem item5 = new MenuItem("Pancake", 2, 2.75);
		MenuItem item6 = new MenuItem("Bacon", 4, 3.25);
		MenuItem item7 = new MenuItem("Eggs", 2, 1.75);
		MenuItem item8 = new MenuItem("Steak", 2, 9.50);
		
		
		MenuItem item9 = new MenuItem("Goat", 1, 7.50);
		MenuItem item10 = new MenuItem("Rice", 3, 2.50);
		MenuItem item11 = new MenuItem("Greens", 4, 1.85);
		MenuItem item12 = new MenuItem("Fish", 2, 7.50);
		MenuItem item13 = new MenuItem("Beans", 2, 2.50);
		MenuItem item14 = new MenuItem("Shrimp", 4, 6.50);
		MenuItem item15 = new MenuItem("Chicken", 2, 4.75);
		MenuItem item16 = new MenuItem("Peas", 2, 1.50);
		MenuItem item17 = new MenuItem("Steak", 2, 9.50);
		MenuItem item18 = new MenuItem("Pizza", 2, 6.25);

		
		order1.insert(item1);
		order1.insert(item2);
		order1.insert(item3);
		order1.insert(item4);
		order1.insert(item5);
		order1.insert(item6);
		order1.insert(item7);
		order1.insert(item8);
		order1.insert(item4);
		order1.insert(item6);



		order2.insert(item9);
		order2.insert(item10);
		order2.insert(item11);
		order2.insert(item12);
		order2.insert(item13);
		order2.insert(item14);
		order2.insert(item15);
		order2.insert(item16);
		order2.insert(item17);
		order2.insert(item18);

		
		System.out.println(order1);
		
		System.out.println("************************************\n\n");
		
		System.out.println(order2);
		
		System.out.println("************************************\n");
		System.out.println("Printing in PreOrder for order1 ");
		order1.preorder();
		
		System.out.println("************************************\n");
		System.out.println("Printing in InOrder for order1");
		order1.inorder();
		
		System.out.println("************************************\n");
		System.out.println("Printing in PostOrder for order1");
		order1.postorder();
		
		System.out.println("************************************\n");
		System.out.println("Printing in PreOrder for order2 ");
		order2.preorder();
		
		System.out.println("************************************\n");
		System.out.println("Printing in InOrder for order2");
		order2.inorder();
		
		System.out.println("************************************\n");
		System.out.println("Printing in PostOrder for order2");
		order2.postorder();


		System.out.println("************************************\n");

		System.out.println("Size of order1 is: " + order1.size());
		System.out.println("Size of order2 is: " + order2.size());
		
		System.out.println("************************************\n");

		System.out.println("Depth of order1 is: " + order1.depth());
		System.out.println("Depth of order2 is: " + order2.depth());
		
		System.out.println("************************************\n");

		System.out.println("Total Qty of order1 is: " + order1.getTotalQty());
		System.out.println("Total Qty of order2 is: " + order2.getTotalQty());
		
		System.out.println("************************************\n");

		System.out.println("Search order1 for \"Sushi\": " + order1.search("Sushi"));
		System.out.println("Search order1 for \"Rice\": " + order1.search("Rice"));
		System.out.println("Search order1 for \"Injera\": " + order1.search("Injera"));

		System.out.println("************************************\n");

		System.out.println("Search order2 for \"Chicken\": " + order2.search("Chicken"));
		System.out.println("Search order2 for \"Shrimp\": " + order2.search("Shrimp"));
		System.out.println("Search order2 for \"Goat\": " + order2.search("Goat"));
		
		System.out.println("************************************\n");

		System.out.println("Total price before tax of order1 is: $" + order1.getTotalBeforeTax());
		System.out.println("Total price before tax of order2 is: $" + order2.getTotalBeforeTax());

		System.out.println("************************************\n");

		System.out.println("Total price After tax of order1 is: $" + fl.format(order1.getTax(0.08)));
		System.out.println("Total price After tax of order2 is: $" + fl.format(order2.getTax(0.08)));
		
		System.out.println("************************************\n");

		System.out.println("Total Tip before tax of order1 is: $" + fl.format(order1.getTip(0.2)));
		System.out.println("Total Tip before tax of order2 is: $" + fl.format(order2.getTip(0.2)));

	}

}
